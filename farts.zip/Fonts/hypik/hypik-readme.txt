    __                _ __  
   / /_  __  ______  (_) /__
  / __ \/ / / / __ \/ / //_/
 / / / / /_/ / /_/ / / ,<   
/_/ /_/\__, / .___/_/_/|_|  
      /____/_/              

————————————————————————————

Thanks for downloading HYPIK™

hypik.otf / Version 1.0 / January 2022



ABOUT THIS FONT
———————————————

This font was inspired by Roadam by HVNTER, the Vector Heart design movement, and Björk's logo. Apologies that there are no numbers or punctuation. Want to flesh out or improve this font? Feel free! Please see the included Adobe Illustrator file for information on how it was created. Feedback and general comments are welcomed. Visit mattcolewilson.com for more. 



TERMS OF USE
————————————

This font is completely free for both personal and commercial use. The distribution of this font for financial gain or profit is not permitted under any circumstances. Free distribution is allowed, if you link back to my site: https://mattcolewilson.com/resources

If you have any questions or comments, please email me!



CONTACT INFORMATION
———————————————————

Email: mattcolewilson@gmail.com

Web: https://mattcolewilson.com

Twitter: http://twitter.com/mattcolewilson

Dribbble: http://dribbble.com/mattcolewilson

